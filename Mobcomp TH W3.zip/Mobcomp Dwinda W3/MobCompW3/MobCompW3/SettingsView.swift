//
//  SettingsView.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Settings")
    }
}

#Preview {
    SettingsView()
}
