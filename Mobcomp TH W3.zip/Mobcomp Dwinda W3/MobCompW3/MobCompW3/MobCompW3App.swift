//
//  MobCompW3App.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

@main
struct MobCompW3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
