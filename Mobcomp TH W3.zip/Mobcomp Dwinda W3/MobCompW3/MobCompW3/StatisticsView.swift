//
//  StatisticsView.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

struct StatisticsView: View {
    var body: some View {
        Text("Statistics")
    }
}

#Preview {
    StatisticsView()
}
