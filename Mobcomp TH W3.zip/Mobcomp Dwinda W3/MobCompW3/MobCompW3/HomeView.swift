//
//  ContentView.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {

        ZStack{
            Color(.systemGray6)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                // header
                HStack{
                    VStack(alignment: .leading){
                        Text("Good Morning,")
                            .font(.system(.title2, design: .serif))
                            .foregroundColor(.gray)
                        Text("Mikaela")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                    }
                    Spacer()
                    Image(systemName:"person.crop.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                }
                .padding(.horizontal)
                
                // search bar
                TextField("Search", text: .constant(""))
                    .padding()
                    .background(Color(.white))
                    .cornerRadius(20)
                    .padding(.horizontal)
                
                // today's goal
                VStack{
                    Text("Today's Goal")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                    HStack{
                        GoalCard(icon: "figure.run", title: "4 Miles", subtitle: "@Thames Route", color: .white)
                        GoalCard(icon: "sailboat.fill", title: "2 Miles", subtitle: "@River Lea", color: .white)
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, minHeight: 250)
                .background(LinearGradient(colors: [.blue, .pink, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                .cornerRadius(30)
                .padding()
                
                HStack(spacing: 16) {
                    StatCard(icon: "heart.fill", value: "68 Bpm", color: .purple)
                    StatCard(icon: "flame.fill", value: "0 Kcal", color: .orange)
                }
                .padding(.horizontal)
                HStack(spacing: 16) {
                    StatCard(icon: "scalemass.fill", value: "73 Kg", color: .green)
                    StatCard(icon: "moon.zzz.fill", value: "6.2 Hr", color: .blue)
                }
                .padding(.horizontal)
            }
            .padding()
        }
    }
}


struct GoalCard: View {
    var icon: String
    var title: String
    var subtitle: String
    var color: Color
    
    var body: some View {
        VStack{
            Image(systemName: icon)
                .font(.system(size: 50, weight: .bold))
                .foregroundColor(.white)
                .padding(.bottom, 10)
            Text(title)
                .font(.headline)
                .foregroundColor(.white)
            Text(subtitle)
                .font(.caption)
                .foregroundColor(.white.opacity(0.8))
        }
        .frame(maxWidth: .infinity, minHeight: 150)
        .background(color.opacity(0.3))
        .cornerRadius(15)
    }
}

struct StatCard: View {
    var icon: String
    var value: String
    var color: Color
    
    var body: some View {
        ZStack {

            VStack {
                HStack {
                    Image(systemName: icon)
                        .foregroundColor(color)
                        .font(.system(.title2, design: .serif))
                        .padding([.top, .leading], 8)
                    Spacer()
                }
                HStack {
                    Spacer()
                    Text(value)
                        .font(.headline)
                        .foregroundColor(.black)
                        .padding([.bottom, .trailing], 8)
                }
            }
            .padding(15) // jarak dari tepi
        }
        .frame(maxWidth: .infinity, minHeight: 70)
        .background(Color.white)
        .cornerRadius(25)
    }
}

#Preview {
    ContentView()
}
