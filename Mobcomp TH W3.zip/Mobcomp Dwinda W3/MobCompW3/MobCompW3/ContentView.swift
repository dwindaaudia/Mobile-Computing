//
//  ContentView.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }

            LocationView()
                .tabItem {
                    Label("Location", systemImage: "location.fill")
                }

            StatisticsView()
                .tabItem {
                    Label("Statistics", systemImage: "chart.bar.xaxis.ascending")
                }

            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
        }
        .tint(.red) // warna icon aktif
        .background(Color.white) // warna tab bar background
    }
}

#Preview {
    ContentView()
}
