//
//  LocationView.swift
//  MobCompW3
//
//  Created by MELIA CATHARINA on 29/09/25.
//

import SwiftUI

struct LocationView: View {
    var body: some View {
        Text("Location")
    }
}

#Preview {
    LocationView()
}
