//
//  CounterVM.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

import Foundation
import SwiftUI

@Observable
// observable dia bisa digunakan/dibaca dimanapun (public class)
// jadi kalau misal kita punya mirror view, maka count nya akan tetep sama walaupun kita melakukan action di view yang beds
final class CounterVM {
    var count: Int = 0
    var isEven : Bool { count % 2 == 0}
    
    func increment() {
        count += 1
    }
    func decrement() { count -= 1 }
    func reset () { count = 0 }
}
