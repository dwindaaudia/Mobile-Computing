//
//  TaskViewModel.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

// view model berisi semua data
import Foundation
import Observation
import SwiftUI

@Observable
final class TaskViewModel {
    var tasks : [Task] = [
        .init(title: "Beli Booster"),
        .init(title: "Beli Celana Baru", isCompleted: true)
    ]
     
    func add(_ title: String){
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        //kalo ada spasi di blkg atau depan akan dihilangkan
        if clean.isEmpty { return }
        tasks.append(.init(title: clean))
    }
    
    func remove(at offsets: IndexSet){
        tasks.remove(atOffsets: offsets)
    }
    
    func toggle(_ task: Task){
        if let idx = tasks.firstIndex(where: { $0.id == task.id }){
            // $0 adalah dimana task yg dipilih itu sama dengan task yang diindex
            // first index mengembalikan index pertama yang ditemukan dengan yang ada di collection task
            tasks[idx].isCompleted.toggle()
        }
    }
}
