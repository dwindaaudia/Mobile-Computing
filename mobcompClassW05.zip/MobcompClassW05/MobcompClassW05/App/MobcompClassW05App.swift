//
//  MobcompClassW05App.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct MobcompClassW05App: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
    }
}
