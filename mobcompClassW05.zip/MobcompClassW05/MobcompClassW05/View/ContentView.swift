//
//  ContentView.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

// Model - View Model - View
// siwft file bisa struct, 

import SwiftUI

struct CounterHomeView: View {
    @State private var vm = CounterVM()
    
    var body: some View {
        NavigationStack{
            VStack(spacing: 16) {
                Text("Count: \(vm.count)")
                    .font(.largeTitle).bold()
                Text(vm.isEven ? "Even" : "Odd")
                    .foregroundStyle(.secondary)
                HStack{
                    Button("+") {vm.increment()}
                        .buttonStyle(.bordered)
                    Button("-") {vm.decrement()}
                        .buttonStyle(.bordered)
                }
                Button("Reset") {vm.reset()}
                    .buttonStyle(.borderedProminent)
            }
            NavigationLink("Mirror Screen"){
                CounterMirrorView(vm: vm)
                //vm kiri punya mirrorview sama dengan (:) punya vm homeview
            }
        }
    }
}

struct CounterMirrorView: View {
    var vm: CounterVM
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Mirror Count: \(vm.count)")
            Button("Add Here") {vm.increment()}
        }
        .font(.title2)
        .padding()
    }
}

#Preview {
    CounterHomeView()
}
