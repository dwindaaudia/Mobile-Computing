//
//  Fruit.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

import Foundation
// impr foundation ini by default

struct Fruit: Identifiable, Codable, Hashable {
    // identifiable who's who. sama kaya primary key kalo di database
    // codeable kalau struct ini bisa komunikasi dgn file lain / API
    // hashable swift bisa melakukan komparasi / track codenya
    
    let UUID: UUID // Universal Uniq ID
    let id: String // A001
    let name: String // Apple
    let color: String // Green
    
//    ForEach (fruits, id: \.color) (fruit) in {
//        
//    }
}
