//
//  Task.swift
//  MobcompClassW05
//
//  Created by student on 09/10/25.
//

// model hanya mendeklarasi strukturnya aja / kerangkanya
import Foundation
struct Task: Identifiable, Codable, Hashable {
    var id = UUID()
    // berarti UUID dibuatkan oleh system
    // kalo : UUID berarti kita init parameter UUID
    var title : String
    var isCompleted : Bool = false
}
