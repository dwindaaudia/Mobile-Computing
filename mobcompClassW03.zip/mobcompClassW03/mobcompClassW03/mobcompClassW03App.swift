//
//  mobcompClassW03App.swift
//  mobcompClassW03
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct mobcompClassW03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
