//
//  ContentView.swift
//  mobcompClassW03
//
//  Created by student on 25/09/25.
//

import SwiftUI



struct ContentView: View {
    @State private var textKu = ""
    var body: some View {
        NavigationStack{
            VStack{
                Text("🏠Home Screen")
                    .font(.largeTitle)
                NavigationLink("Go to details"){
                    DetailScreen()
                }
                NavigationLink("Go to Items"){
                    ItemScreen()
                }
            }
        }
        VStack {
            TabView {
                HomeView()
                    .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .badge("11")
                SearchView()
                    .tabItem{
                        Label("Search", systemImage: "magnifyingglass")
                    }
                AccountView()
                    .tabItem {
                        Label("Account", systemImage: "person.circle")
                    }
                MessageView()
                    .tabItem {
                        Label("Messages", systemImage: "envelope")
                    }
            }
        }
    }
}
    
struct DetailScreen: View{
    var body: some View{
        VStack{
            Text("🩻 Detail Screen")
                .font(.largeTitle)
            Text("You come from home screen!")
        }
        .navigationTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemScreen: View{
    let items = ["🍅 Tomato", "🍌 Banana","🍇 Grape", "🍊 Orange", "🫐 Blueberry", "🍋 Lemon"]
    
    var body: some View{
        List(items, id: \.self){
            item in NavigationLink(destination: ItemDetailScreen(item: item)) {
                Text(item)
            }
        }
//        .navigationDestination(for: String.self){ item in ItemDetailScreen(item: item)
//        }
        .navigationTitle("Items")
    }
}


struct ItemDetailScreen: View {
    let item: String
    
    var body: some View{
        VStack{
            Text("Welcome to item detail!")
                .font(.title)
            Text("You selected : \(item)")
        }
        .navigationTitle(item)
    }
}


struct HomeView: View {
    var body: some View {
        VStack{
            Text("🏡 Home!")
                .font(.largeTitle)
            Text("Tasks ")
                .font(.headline)
            
//            ForEach(0..<10){
//                number in Text("Task \(number)")
//            }
        }
    }
}

struct SearchView: View {
    var body: some View {
        VStack{
            Text("🔍 Search!")
                .font(.largeTitle)
        }
    }
}

struct AccountView: View {
    var body: some View {
        VStack{
            Text("👤 Account!")
                .font(.largeTitle)
        }
    }
}

struct MessageView: View {
    var body: some View {
        VStack{
            Text("💌 Message!")
                .font(.largeTitle)
        }
    }
}


#Preview {
    ContentView()
}
