//
//  CounterView.swift
//  mobcompClassW03
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct CounterView: View {
    @Binding var count: Int
    
    var body: some View {
        VStack{
            Text("Child View (Counter View)")
                .font(.headline)
            HStack{
                Button("-"){
                    count -= 1
                }
                .buttonStyle(.bordered)
                .background(.red)
                .cornerRadius(10)
                Button("+"){
                    count += 1
                }
                .buttonStyle(.bordered)
                .background(.red)
                .cornerRadius(10)
            }
        }
        .padding()
        .background(.blue)
        .cornerRadius(10)
    }
}
