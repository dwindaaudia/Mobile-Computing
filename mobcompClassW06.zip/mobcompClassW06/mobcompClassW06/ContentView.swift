//
//  ContentView.swift
//  mobcompClassW06
//
//  Created by student on 16/10/25.
//

import SwiftUI

enum LoadingState {
    case idle
    case loading
    case succes(data: String)
    case error(message: String)
}

struct ContentView: View {
    // Enum
    @State private var state: LoadingState = .idle
    
    enum Grade : String, CaseIterable{
        case A, B, C, D, E
        
        var color: Color {
            switch self {
            case .A: return .green
            case .B: return .yellow
            case .C: return .blue
            case .D: return .orange
            case .E: return .black
            }
        }
    }
    
   
    @State private var grade: Grade = .A
    
    // Tuple
    @State private var point: (x: Int, y: Int) = (x: 0, y:0)
    
    // Set
    @State private var programmingLanguage: Set<String> = ["Swift", "Phyton", "JavaScript"]
    @State private var newLang: String = ""
    
    //Class
    @Observable
    class Counter {
        var count: Int = 0
        func increment() { count += 1 }
        func decrement() { count -= 1 }
    }
    
    @State private var counterA = Counter()
    @State private var counterB: Counter? = nil
    
    
    @State private var newName: String = ""
    @State private var newScore: String = ""

    //ini namanya dictionary
    @State private var scores: [String: Int] = [
        "Alice": 90,
        "Martini": 80,
        "Sutris": 20,
    ]
    
    var body: some View {
        // Enum
        VStack{
            Group{
                switch state {
                case.idle:
                    Text("Tap to start loading")
                case .loading:
                    ProgressView("Loading...")
                case .succes(data: let data):
                    Text("Loaded: \(data)")
                        .foregroundColor(Color.green)
                case .error(message: let msg):
                    Text("Error: \(msg)")
                        .foregroundColor(Color.red)
                }
            }
            HStack{
                Button("Start") { state = .loading}
                Button("Success") { state = .succes(data: "yeeeyy sukses")}
            }
        }
        
//        // contoh enum grade nilai
//        VStack{
//            Picker("Select Grade", selection: $grade) {
//                ForEach(Grade.allCases, id: \.self) { g in
//                    Text(g.rawValue)
//                }
//            }
//            .pickerStyle(.segmented)
//            
//            Text("Your Grade: \(grade.rawValue)")
//                .font(Font.largeTitle.bold())
//                .foregroundColor(grade.color)
//        }
//        
        
//        // Tuple
//        // bisa nerima value duplicate tapi urutannya gak bisa diubah. umumnya berbentuk let atau biasa disebut data temporary
//        VStack{
//            Text("ini adalah tuple")
//                .font(Font.largeTitle)
//            
//            Text("Nilai sekarang XY : \(point.x) , \(point.y)")
//            
//            HStack{
//                Button("Kanan 10 langkah"){
//                    point.x += 10
//                }
//                .buttonStyle(.borderedProminent)
//                Button("Kebawah 10 langkah") {
//                    point.y -= 10
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
//        
        
//        // Set
//        // gak bisa akses by index karena dia gak punya urutan, dan gak bisa duplicate juga
//        VStack{
//            Text("Ini adalah set")
//                .font(Font.largeTitle)
//            HStack{
//                ForEach(Array(programmingLanguage), id: \.self) {lang in
//                    Text(lang)
//                        .padding(5)
//                        .background(.green)
//                        .clipShape(Capsule())
//                }
//            }
//            HStack{
//                TextField("Enter New Languange", text: $newLang)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .frame(width:200)
//                
//                Button("Add"){
//                    if !newLang.isEmpty {
//                        programmingLanguage.insert(newLang)
//                        newLang = ""
//                    }
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
        
//        // Class
//        VStack{
//            Text("Counter A: \(counterA.count)")
//            Text("Counter B: \(counterB?.count ?? 0)")
//                .foregroundStyle(counterB === nil ? .red : .primary)
//        }
//        HStack{
//            Button("+") { counterA.increment()}
//            Button("-") { counterA.decrement()}
//            
//            Button(counterB == nil ? "Clone A to B " : "Unlink B"){
//                if counterB == nil {
//                    counterB = counterA
//                } else {
//                    counterB = nil
//                    
//                }
//            }.buttonStyle(BorderedButtonStyle())
//            
//            Button("+") { counterB?.increment() }
//        }
        
        
        
//        // Dictionary
//        VStack{
//            Text("Dictionary Explanation")
//                .font(Font.largeTitle)
//            VStack{
//                ForEach(scores.sorted(by: { $0.key < $1.key
//                // 0 itu dari index pertama (nama String), 1 dari (score Int)
//                }), id: \.key){
//                    name, score in
//                    HStack{
//                        Text(name)
//                        Spacer()
//                        Text("\(score)")
//                            .bold(true)
//                    }
//                }
//            }.padding(20)
//            HStack{
//                Button("Increase butris' Score!"){
//                    scores["Butris", default:0] += 5
//                    // kalo gaada nama butris dia akan nge create baru
//                }
//                .buttonStyle(.borderedProminent)
//            }
//            
//            // buat button untuk ngedelete semua value sak nama2e
//            Button("Delete all Value"){
//                scores.removeAll()
//            }
//            .buttonStyle(.borderedProminent)
//            
//            // button nambah nama student sesuai input textfield
//            VStack(spacing: 10) {
//                TextField("Enter name", text: $newName)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                            
//                TextField("Enter score (number)", text: $newScore)
//                    .keyboardType(.numberPad)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                            
//                Button("Add Student Score") {
//                    if let score = Int(newScore), !newName.isEmpty {
//                        scores[newName] = score
//                        newName = ""
//                        newScore = ""
//                    }
//                }
//            }
//
//            
//        }
//    }
    
    
//    @State private var fruits: [String] = ["Apple", "Pear", "Durian"]
//    
//    var body: some View {
//        VStack {
//            Text("Array of fruits")
//                .font(.largeTitle)
//            
//            HStack{
//                ForEach(fruits, id: \.self) { fruit in Text (fruit)
//                        .padding(10)
//                        .background(Color.orange.opacity(0.3))
//                        .clipShape(Capsule())
//                }
//            }
//            HStack{
//                Button("Add Fruit"){
//                    fruits.append("Banana")
//                }.buttonStyle(.borderedProminent)
//                
//                Button("Remove Last")
//                {
//                    if !fruits.isEmpty {
//                        fruits.removeLast()
//                    }
//                }
//            }
//        }

    }
}

#Preview {
    ContentView()
}
