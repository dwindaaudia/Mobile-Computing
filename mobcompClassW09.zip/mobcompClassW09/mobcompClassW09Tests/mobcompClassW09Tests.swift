//
//  mobcompClassW09Tests.swift
//  mobcompClassW09Tests
//
//  Created by student on 06/11/25.
//

import Testing
@testable import mobcompClassW09

struct mobcompClassW09Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
