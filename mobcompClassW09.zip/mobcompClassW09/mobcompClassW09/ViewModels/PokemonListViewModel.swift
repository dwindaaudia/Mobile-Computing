//
//  PokemonListVM.swift
//  W9_ClassExercise
//
//  Created by jessica tedja on 06/11/25.
//

import Foundation
import Combine

//ViewModel akan running di main thread, jalan sbgai aktor utama, klo ada perubhan akan lgsg update
@MainActor
final class PokemonListViewModel: ObservableObject {
    @Published var items: [NamedAPIResource] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var searchText: String = ""
    
    private var canLoadMore = true
    private var offset = 0
    private let pageSize = 40
    
    func refresh() async {
        offset = 0
        canLoadMore = true
        items.removeAll()
        await loadMoreIfNeeded(force: true)
    }
    
    func loadMoreIfNeeded(currentItem item: NamedAPIResource? = nil,
                          force: Bool = false) async {
        guard (force || shouldLoadMore(after: item)),
              canLoadMore, !isLoading else { return }
        await loadPage()
    }
    
    private func shouldLoadMore(after item: NamedAPIResource?) -> Bool {
        guard let item = item else { return true }
        guard let idx = items.firstIndex(where: { $0.id == item.id }) else {
            return false
        }
        return idx >= items.count - 5
    }
    
    private func loadPage() async {
        guard let url = PokemonAPI.listURL(limit: pageSize, offset: offset) else {
            errorMessage = APIError.badUrl.localizedDescription
            return
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let page: PokemonListResponse = try await APIService.shared.fetch(url)
            items.append(contentsOf: page.results)
            canLoadMore = (page.next != nil)
            offset += pageSize
        } catch {
            if let apiErr = error as? APIError {
                errorMessage = apiErr.localizedDescription
            } else {
                errorMessage = error.localizedDescription
            }
        }
    }
    
    var filteredItems: [NamedAPIResource] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return items }
        return items.filter { $0.name.contains(q) }
    }
}
