//
//  mobcompClassW09App.swift
//  mobcompClassW09
//
//  Created by student on 06/11/25.
//

import SwiftUI

@main
struct mobcompClassW09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
