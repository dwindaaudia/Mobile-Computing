//
//  ucflixTests.swift
//  ucflixTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import ucflix

struct ucflixTests {

    @Test func example() async throws {
        
    }

}
