//
//  MovieDetailView.swift
//  ucflix
//
//  Created by student on 02/10/25.
//
// File: MovieDetailView.swift

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // Poster dari URL
                AsyncImage(url: URL(string: movie.posterURL)) { phase in
                    if let image = phase.image {
                        image.resizable()
                    } else {
                        Rectangle().fill(.gray.opacity(0.3)).frame(height: 300)
                    }
                }
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: .infinity)
                
                Group {
                    // Detail: Title, Genre (Kriteria Interaktivitas)
                    Text(movie.title)
                        .font(.largeTitle).bold()
                    
                    Text("Genre: \(movie.genre)")
                        .font(.headline)
                    
                    Text(movie.synopsis)
                        .padding(.top, 10)
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle(movie.title) 
        .navigationBarTitleDisplayMode(.inline)
    }
}


struct SearchBarView: View {
    
    // Properti ini menerima data yang dapat diubah
    // dari parent View (ContentView). Ini memenuhi kriteria @Binding.
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            // TextField terikat ke 'text' yang terikat ke $searchText di ContentView
            TextField("Cari judul atau genre film...", text: $text)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 10)
        .background(Color(.systemGray6))
        .cornerRadius(10)
        .padding(.horizontal, 25)
    }
}
