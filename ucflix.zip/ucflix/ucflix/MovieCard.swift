//
//  MovieCard.swift
//  ucflix
//
//  Created by student on 02/10/25.
//
// File: MovieCard.swift

import SwiftUI

struct MovieCard: View {
    let movie: Movie

    var body: some View {
        ZStack(alignment: .bottomLeading)
            
            // poster dari URL
            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                if let image = phase.image {
                    image.resizable()
                } else if phase.error != nil {
                    Image(systemName: "xmark.octagon.fill").foregroundColor(.red).font(.title)
                } else {
                    ProgressView()
                }
            }
            .aspectRatio(contentMode: .fill)
            .frame(width: 170, height: 250)
            
            LinearGradient(gradient: Gradient(colors: [.clear, .black.opacity(0.8)]), startPoint: .center, endPoint: .bottom)
                .frame(height: 100)
            
            // title
            VStack(alignment: .leading) {
                Text(movie.title)
                    .font(.headline)
                    .foregroundColor(.white)
                    .lineLimit(2)
             // rating
                Text(String(format: "%.1f ⭐️", movie.rating))
                    .font(.caption)
                    .foregroundColor(.yellow)
            }
            .padding([.leading, .bottom], 10)
        }
        .frame(width: 170, height: 250)
        .cornerRadius(12) // Menggunakan Modifiers
        .shadow(radius: 8) // Menggunakan Modifiers
    }
}
