//
//  ucflixApp.swift
//  ucflix
//
//  Created by student on 02/10/25.
//


import SwiftUI

@main
struct ucflixApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() 
        }
    }
}

