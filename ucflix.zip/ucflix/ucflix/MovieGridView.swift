//
//  MovieGridView.swift
//  ucflix
//
//  Created by student on 02/10/25.
//
// File: MovieGridView.swift

import SwiftUI

struct MovieGridView: View {
    let movies = Movie.sampleMovies
  
    @State private var showingHighRated: Bool = false
    
    var filteredMovies: [Movie] {
        if showingHighRated {
            return movies.filter { $0.rating >= 4.0 }
        } else {
            return movies
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                
                // filter rating
                Toggle("Show High Rating Movies", isOn: $showingHighRated)
                    .padding(.horizontal)
                    .padding(.top)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                    
                    ForEach(filteredMovies) { movie in

                        NavigationLink(value: movie) {
                            MovieCard(movie: movie)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding()
            }
            .navigationTitle("UCFlix")
            .navigationDestination(for: Movie.self) { movie in
                MovieDetailView(movie: movie)
            }
        }
    }
}
