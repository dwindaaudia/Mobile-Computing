// File: MovieStore.swift

import Foundation
import Combine

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(title: "The Gray Man", posterURL: "https://occ-0-8407-2219.1.nflxso.net/dnm/api/v6/mAcAr9TxZIVbINe88xb3Teg5_OA/AAAABVuKN6f-4-ByM9rS6HLDWpQTwHdlamYlU39JFtJ68en_n00Rucuwg2SlSa7wq8UgCZdRoasJtOJldjYzQs6B7UEe4nUhCvNSn6x-0aX2UTzq4hJq2ws7QjFfodg0ikxh_RFF.webp?r=35c", genre: "Action", synopsis: "A highly skilled CIA operative known as The Gray Man uncovers dangerous secrets about his agency, turning him into a target. As he races across the globe, he must use all his skills to survive and expose the truth while being hunted by ruthless assassins.", rating: 4.5),
        Movie(title: "The Trauma Code", posterURL: "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/222/2025/09/24/IMG-20250924-WA0016-312648346.jpg", genre: "Drama", synopsis: "This story delves into the intense world of trauma care, following medical professionals as they face life-and-death situations in emergency rooms. It explores the emotional and physical challenges they endure while saving lives under pressure.", rating: 3.8),
        Movie(title: "Alice in Bonderland", posterURL: "https://www.fsunews.com/gcdn/presto/2023/01/15/PFSU/2821e7df-1732-4157-9904-72938c88bba0-alice_in_borderland.jpeg?width=1200&disable=upscale&format=pjpg&auto=webp", genre: "Sci-fi, Thriller", synopsis: "After a mysterious event, a group of friends find themselves trapped in a deserted Tokyo where they must compete in deadly games to survive. As they navigate this twisted world, they uncover dark secrets about the game's true purpose and the nature of their reality.", rating: 4.2),
        Movie(title: "The Meg", posterURL: "https://m.media-amazon.com/images/S/pv-target-images/02476fb253907e89602e422d3bed5ec8dbeec1d4c55bc8d8eb5c06032eb4e716.jpg", genre: "Action, Survival", synopsis: "A deep-sea rescue diver encounters a massive prehistoric shark, the Megalodon, while on a mission to save trapped scientists. Facing the enormous predator, he must fight for survival and prevent the creature from wreaking havoc on the surface world.", rating: 2.9),
        Movie(title: "Twenty-Five Twenty-One", posterURL: "https://m.media-amazon.com/images/M/MV5BYTdjZWExZmMtZTY0Yy00N2U3LTkyYmYtMGNjZjUyZTM0Njg0XkEyXkFqcGc@._V1_.jpg", genre: "Romance, Drama", synopsis: "This drama tells the story of love and friendship between two teenagers growing up during the significant changes in South Korea in the 1990s. It focuses on a girl aspiring to become a professional fencer and a young man struggling to overcome his family’s hardships. The series is filled with emotional moments, personal growth, and the passion to chase dreams.", rating: 5.0),
        Movie(title: "Welcome to Samdal-ri", posterURL: "https://images.justwatch.com/poster/309777566/s718/season-1.jpg", genre: "Romance", synopsis: "Set in a small rural village, this drama explores the lives, struggles, and relationships of its residents as they face changes and challenges in their community. It highlights themes of friendship, family, and the simple yet meaningful moments of everyday life in a close-knit town.", rating: 4.5)
    ]
    
    @Published var showingHighRated: Bool = false
    
    var filteredMoviesByRating: [Movie] {
        if showingHighRated {
            return movies.filter { $0.rating >= 4.0 }
        } else {
            return movies
        }
    }
}
