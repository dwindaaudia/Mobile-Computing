//
//  ContentView.swift
//  ucflix
//
//  Created by student on 02/10/25.
//

import SwiftUI
import Foundation


struct Movie: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let posterURL: String
    let genre: String
    let synopsis: String
    let rating: Double
}

struct MovieCard: View {
    let movie: Movie

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            
            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                if let image = phase.image {
                    image.resizable()
                } else {
                    ProgressView()
                }
            }
            .aspectRatio(contentMode: .fill)
            .frame(width: 170, height: 250)
    
            LinearGradient(gradient: Gradient(colors: [.clear, .black.opacity(0.8)]), startPoint: .center, endPoint: .bottom)
                .frame(height: 100)
            
            VStack(alignment: .leading) {
                Text(movie.title)
                    .font(.headline)
                    .foregroundColor(.white)
                    .lineLimit(2)
                
                Text(String(format: "%.1f ⭐️", movie.rating))
                    .font(.caption)
                    .foregroundColor(.yellow)
            }
            .padding([.leading, .bottom], 10)
        }
        .frame(width: 170, height: 250)
        .cornerRadius(12)
        .shadow(radius: 8)
    }
}


struct MovieDetailView: View {
    let movie: Movie

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // Poster dari URL
                AsyncImage(url: URL(string: movie.posterURL)) { phase in
                    if let image = phase.image {
                        image.resizable()
                    } else {
                        Rectangle().fill(.gray.opacity(0.3)).frame(height: 300)
                    }
                }
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: .infinity)
                
                Group {
                    Text(movie.title)
                        .font(.largeTitle).bold() // Kriteria Detail Screen
                    
                    Text("Genre: \(movie.genre)")
                        .font(.headline)
                    
                    Text(movie.synopsis)
                        .padding(.top, 10)
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}


struct SearchBarView: View {
    
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Cari judul atau genre film...", text: $text)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
        }

        .padding(.vertical, 8)
        .padding(.horizontal, 10)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}
struct ContentView: View {
    

    @StateObject var store = MovieStore()
    @State private var searchText: String = ""
    
  
    var filteredMovies: [Movie] {
  
        var results = store.filteredMoviesByRating
       
        if !searchText.isEmpty {
            results = results.filter {
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.genre.localizedCaseInsensitiveContains(searchText)
            }
        }
            
        return results
    }

    var body: some View {
        
        NavigationStack {
            
            Text("Your Movies by UCFlix")
                .font(.title.bold())
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.init(top: 10, leading: 25, bottom: 0, trailing: 25))
            
            SearchBarView(text: $searchText)
                .padding(.horizontal, 25)
            
            
            
            ScrollView {
                Toggle("Show High Rating Movies", isOn: $store.showingHighRated)
                    .padding(.init(top: 10, leading: 25, bottom: 10, trailing: 25))
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                    ForEach(filteredMovies) { movie in
                        NavigationLink(value: movie) {
                            MovieCard(movie: movie)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding()
                
                if filteredMovies.isEmpty {
                    Text("Tidak ada film yang cocok dengan pencarian Anda.")
                        .foregroundColor(.gray)
                        .padding(.init(top: 10, leading: 25, bottom: 10, trailing: 25))
                }
            }
            .navigationDestination(for: Movie.self) { movie in
                MovieDetailView(movie: movie)
            }
        }
    }
}
#Preview {
    ContentView()
}
