//
//  mobcompClassW06App.swift
//  mobcompClassW06
//
//  Created by student on 16/10/25.
//

import SwiftUI

@main
struct mobcompClassW06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
